import CreateCustomer from './components/CreateCustomer';

const App = () => {
  return (
    <div>
      <h1>Customer Main Menu</h1>
      <CreateCustomer />
    </div>
  );
};

export default App;