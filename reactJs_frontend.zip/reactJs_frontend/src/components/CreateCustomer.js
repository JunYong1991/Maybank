import React, { useState, useEffect } from 'react';
import './Customer.css';

const CreateCustomer = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [postData, setPostData] = useState({ email: '', password: '' , firstName: '' , lastName: ''  });

  useEffect(() => {
    // Define the API endpoint
    const apiUrl = 'http://localhost:7002/api/cust';

    // Fetch data from the API
    const fetchData = async () => {
      try {
        const response = await fetch(apiUrl);
        const result = await response.json();

        setData(result);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []); // Empty dependency array ensures the effect runs only once, equivalent to componentDidMount

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPostData({ ...postData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Define the API endpoint for creating a new post
    const createPostUrl = 'http://localhost:7002/api/cust';

    try {
      const response = await fetch(createPostUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });

      if (response.ok) {
        // If the post is successfully created, fetch the updated data
        const updatedDataResponse = await fetch('http://localhost:7002/api/cust');
        const updatedData = await updatedDataResponse.json();
        setData(updatedData);
        alert("Save sucessfully")
      } else {
        console.error('Failed to create post:', response.status, response.statusText);
      }
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  return (
    <div>
      <h2>Customer Form</h2>

      <form onSubmit={handleSubmit}>
        <label>
          Email: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;     
          <input type="text" name="email" value={postData.email} onChange={handleInputChange} />
        </label>
        <br />
        <label>
          password: &nbsp; &nbsp;
          <input type="text" name="password" value={postData.password} onChange={handleInputChange} />
        </label>
        <br />
        <label>
          First Name: &nbsp;
          <input type="text" name="firstName" value={postData.firstName} onChange={handleInputChange} />
        </label>
        <br />
        <label>
          Last Name: &nbsp;
          <input type="text" name="lastName" value={postData.lastName} onChange={handleInputChange} />
        </label>
        <br />
        <div>
        <p></p>
        </div>
        <button type="submit">Create Customer</button>
      </form>

      <hr />

      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul>
          {data ? (
                <table>
                    <tr>
                        <th>Id</th>
                        <th>Email</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                    </tr>
                    {data.map((item) => (

                        <tr key={item.id}>

                            <td>{item.id}</td>
                            <td>{item.email}</td>
                            <td>{item.firstName}</td>
                            <td>{item.lastName}</td>

                        </tr>

                    ))}
                </table>
            ) : (
                <p>Loading...</p>
            )}
        </ul>
      )}
    </div>
  );
};

export default CreateCustomer;
