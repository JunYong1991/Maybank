package net.codejava;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

@Controller
public class AppController {

//	@Autowired
//	private UserRepository userRepo;
	
	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}
	
	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("book", new Book());
		
		return "signup_form";
	}
	
	@PostMapping("/process_register")
	public String processRegister(Book book) throws Exception{
		
		System.out.println("Author "+book.getAuthor());
		System.out.println("title "+book.getTitle());
		
       String url = "http://localhost:7001/api/book";
        
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json");
        con.setDoOutput(true);

        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(new Gson().toJson(book).toString());
        wr.flush();
        wr.close();

        int responseCode = con.getResponseCode();
        System.out.println("Response Code: " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        System.out.println(response.toString());
		
		return "register_success";
	}
	
	@GetMapping("/users")
	public String listUsers(Model model) {
		String URL_BOOKS = "http://localhost:7001/api/book";
		RestTemplate restTemplate = new RestTemplate();
		 
        // Send request with GET method and default Headers.
        Book[] list = restTemplate.getForObject(URL_BOOKS, Book[].class);
 
        if (list != null) {
        	
        	model.addAttribute("listBook",list);
        }
		
		return "users";
	}
	@PostMapping("/process_update")
	public String processUpdate(Book book) throws Exception{
		
		System.out.println("Author "+book.getAuthor());
		System.out.println("title "+book.getTitle());
		
       String url = "http://localhost:7001/api/book/"+book.getId();
        
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        con.setRequestMethod("PUT");
        con.setRequestProperty("Content-Type", "application/json");
        con.setDoOutput(true);

        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(new Gson().toJson(book).toString());
        wr.flush();
        wr.close();

        int responseCode = con.getResponseCode();
        System.out.println("Response Code: " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        System.out.println(response.toString());
		
		return "register_success";
	}
	
	@GetMapping("/update/{id}")
	public String updateBook(Model model,@PathVariable(value = "id") long id) {
		Book book = new Book();
		book.setId(id);
		model.addAttribute("book", book);

		return "update_form";
	}
	@GetMapping("delete/{id}")
	public String processDelete(Model model,@PathVariable(value = "id") long id) throws Exception{
		
		
		
       String url = "http://localhost:7001/api/book/"+id;
        
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        con.setRequestMethod("DELETE");
        con.setRequestProperty("Content-Type", "application/json");
        con.setDoOutput(true);

        int responseCode = con.getResponseCode();

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

		
		return "register_success";
	}
}
