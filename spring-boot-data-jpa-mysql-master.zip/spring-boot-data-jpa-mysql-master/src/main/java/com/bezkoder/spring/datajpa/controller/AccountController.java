package com.bezkoder.spring.datajpa.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.spring.datajpa.model.Account;
import com.bezkoder.spring.datajpa.repository.AccountRepository;

@RestController
@RequestMapping("/api")
public class AccountController {

	@Autowired
	AccountRepository accRepository;

	@GetMapping("/account/{custid}")
	public ResponseEntity<List<Account>> getAllAccount(@PathVariable("custid") long custid) {
		try {
			List<Account> acc2 = new ArrayList<Account>();

			accRepository.findByCustid(custid).forEach(acc2::add);

			if (acc2.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(acc2, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/accountAcc/{id}")
	public ResponseEntity<Optional> getAccount(@PathVariable("id") long id) {
		try {
			//List<Account> acc2 = new ArrayList<Account>();

			Optional acc2 = accRepository.findById(id);

			if (acc2.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(acc2, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@PostMapping("/account")
	public ResponseEntity<Account> createAccount(@RequestBody Account acc) {
		try {
			Account _acc = accRepository
					.save(new Account( acc.getCustid(),acc.getAmount(),acc.getStatus()));
			return new ResponseEntity<>(_acc, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/account/{id}")
	public ResponseEntity<Account> updateAccount(@PathVariable("id") long id, @RequestBody Account acc) {
		Optional<Account> accData = accRepository.findById(id);

		if (accData.isPresent()) {
			Account _acc = accData.get();
			_acc.setAmount(acc.getAmount());
			_acc.setStatus(acc.getStatus());
			return new ResponseEntity<>(accRepository.save(_acc), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/account/{id}")
	public ResponseEntity<HttpStatus> deleteAccount(@PathVariable("id") long id) {
		try {
			accRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/account")
	public ResponseEntity<HttpStatus> deleteAllAccount() {
		try {
			accRepository.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@PutMapping("/accountWith/{id}")
	public ResponseEntity<Account> withdraw(@PathVariable("id") long id, @RequestBody Account acc) {
		double Amount;
		Optional<Account> accData = accRepository.findById(id);
        
		if (accData.isPresent()) {
			Account _acc = accData.get();
			Amount= _acc.getAmount()-acc.getAmount();
			_acc.setAmount(Amount);
			_acc.setStatus(acc.getStatus());
			return new ResponseEntity<>(accRepository.save(_acc), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/accountDep/{id}")
	public ResponseEntity<Account> deposit(@PathVariable("id") long id, @RequestBody Account acc) {
		double Amount;
		Optional<Account> accData = accRepository.findById(id);
        
		if (accData.isPresent()) {
			Account _acc = accData.get();
			Amount= _acc.getAmount()+acc.getAmount();
			_acc.setAmount(Amount);
			_acc.setStatus(acc.getStatus());
			return new ResponseEntity<>(accRepository.save(_acc), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

}
